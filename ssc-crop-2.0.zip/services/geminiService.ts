
import { GoogleGenAI, Type } from "@google/genai";
import type { ExtractedData } from "../types";
import { ItemType } from "../types";

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
    throw new Error("API_KEY environment variable is not set");
}

const ai = new GoogleGenAI({ apiKey: API_KEY });

const responseSchema = {
    type: Type.ARRAY,
    items: {
        type: Type.OBJECT,
        properties: {
            id: {
                type: Type.INTEGER,
                description: "The number corresponding to the student (1-9)."
            },
            type: {
                type: Type.STRING,
                enum: [ItemType.PHOTO, ItemType.SIGNATURE],
                description: "The type of item, either PHOTO or SIGNATURE."
            },
            boundingBox: {
                type: Type.OBJECT,
                properties: {
                    x: {
                        type: Type.INTEGER,
                        description: "The x-coordinate of the top-left corner."
                    },
                    y: {
                        type: Type.INTEGER,
                        description: "The y-coordinate of the top-left corner."
                    },
                    width: {
                        type: Type.INTEGER,
                        description: "The width of the bounding box."
                    },
                    height: {
                        type: Type.INTEGER,
                        description: "The height of the bounding box."
                    }
                },
                required: ["x", "y", "width", "height"]
            }
        },
        required: ["id", "type", "boundingBox"]
    }
};

export const extractStudentData = async (imageBase64: string, mimeType: string): Promise<ExtractedData[]> => {
    const prompt = `Analyze this image of a form containing student photographs and signatures. 
    Identify the bounding boxes for all 9 photographs and all 9 signatures. 
    The items are numbered 1 through 9.
    Respond with a JSON object that strictly follows the provided schema. 
    The coordinates must be in pixels, with the origin (0,0) at the top-left corner of the image.
    Ensure there are exactly 18 items in the final array: 9 photos and 9 signatures.`;

    const imagePart = {
        inlineData: {
            data: imageBase64,
            mimeType: mimeType,
        },
    };

    const textPart = { text: prompt };

    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: { parts: [imagePart, textPart] },
            config: {
                responseMimeType: "application/json",
                responseSchema: responseSchema,
            }
        });

        const jsonText = response.text.trim();
        const data = JSON.parse(jsonText);
        
        if (!Array.isArray(data) || data.length === 0) {
            throw new Error("AI response was empty or not an array.");
        }
        
        return data as ExtractedData[];

    } catch (error) {
        console.error("Error calling Gemini API:", error);
        throw new Error("Failed to get a valid response from the AI model.");
    }
};
