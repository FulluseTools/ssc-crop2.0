
import React, { useState } from 'react';
import type { CroppedImage } from '../types';
import { ItemType } from '../types';

interface ResultsDisplayProps {
    images: CroppedImage[];
    onReset: () => void;
}

const ImageCard: React.FC<{ image: CroppedImage }> = ({ image }) => (
    <div className="bg-white/10 p-2 rounded-lg shadow-md flex flex-col items-center text-center">
        <img src={image.dataUrl} alt={`${image.type} ${image.id}`} className="rounded-md object-contain h-32 w-full" />
        <p className="text-sm mt-2 font-semibold text-indigo-200">{`${image.type === ItemType.PHOTO ? 'Photo' : 'Signature'} ${image.id}`}</p>
    </div>
);

export const ResultsDisplay: React.FC<ResultsDisplayProps> = ({ images, onReset }) => {
    const [isZipping, setIsZipping] = useState(false);

    const photos = images.filter(img => img.type === ItemType.PHOTO).sort((a, b) => a.id - b.id);
    const signatures = images.filter(img => img.type === ItemType.SIGNATURE).sort((a, b) => a.id - b.id);

    const handleDownload = async () => {
        setIsZipping(true);
        try {
            const zip = new window.JSZip();
            
            const fetchAndAdd = async (img: CroppedImage) => {
                const response = await fetch(img.dataUrl);
                const blob = await response.blob();
                const filename = `${img.type.toLowerCase()}_${img.id}.jpg`;
                zip.file(filename, blob);
            };

            await Promise.all(images.map(fetchAndAdd));

            const content = await zip.generateAsync({ type: "blob" });
            
            const link = document.createElement("a");
            link.href = URL.createObjectURL(content);
            link.download = "ssc_crop_2.0_results.zip";
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            URL.revokeObjectURL(link.href);

        } catch (error) {
            console.error("Failed to create ZIP file:", error);
            alert("An error occurred while creating the ZIP file. Please try again.");
        } finally {
            setIsZipping(false);
        }
    };


    return (
        <div className="animate-fade-in">
            <div className="flex flex-col md:flex-row justify-center items-center gap-4 mb-8">
                <button
                    onClick={handleDownload}
                    disabled={isZipping}
                    className="w-full md:w-auto flex items-center justify-center gap-2 bg-green-500 text-white font-bold py-3 px-8 rounded-full hover:bg-green-600 transition-all duration-300 transform hover:scale-105 disabled:bg-gray-400 disabled:cursor-not-allowed disabled:scale-100"
                >
                    {isZipping ? (
                        <>
                            <svg className="animate-spin h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                            </svg>
                            Zipping...
                        </>
                    ) : (
                        <>
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
                            </svg>
                            Download All (.zip)
                        </>
                    )}
                </button>
                 <button onClick={onReset} className="w-full md:w-auto bg-pink-500 text-white font-bold py-3 px-8 rounded-full hover:bg-pink-600 transition-all duration-300 transform hover:scale-105">
                    Crop Another Image
                </button>
            </div>

            <div className="space-y-8">
                <div>
                    <h3 className="text-2xl font-bold mb-4 border-b-2 border-pink-400 pb-2">Photos ({photos.length})</h3>
                    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 lg:grid-cols-9 gap-4">
                        {photos.map(p => <ImageCard key={`photo-${p.id}`} image={p} />)}
                    </div>
                </div>
                <div>
                    <h3 className="text-2xl font-bold mb-4 border-b-2 border-pink-400 pb-2">Signatures ({signatures.length})</h3>
                    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 lg:grid-cols-9 gap-4">
                         {signatures.map(s => <ImageCard key={`sig-${s.id}`} image={s} />)}
                    </div>
                </div>
            </div>
        </div>
    );
};
