import React, { useRef, useEffect, useState, useCallback } from 'react';
import { ItemType } from '../types';

interface ItemToCrop {
    name: string;
    type: ItemType;
    id: number;
}

interface CropModalProps {
    imageUrl: string;
    itemToCrop: ItemToCrop;
    onCrop: (dataUrl: string) => void;
    onClose: () => void;
}

interface Rect {
    x: number;
    y: number;
    width: number;
    height: number;
}

export const CropModal: React.FC<CropModalProps> = ({ imageUrl, itemToCrop, onCrop, onClose }) => {
    const canvasRef = useRef<HTMLCanvasElement>(null);
    const imageRef = useRef<HTMLImageElement>(new Image());
    const [cropRect, setCropRect] = useState<Rect | null>(null);
    const [isDrawing, setIsDrawing] = useState(false);
    const [startPoint, setStartPoint] = useState<{ x: number, y: number } | null>(null);

    const draw = useCallback(() => {
        const canvas = canvasRef.current;
        const image = imageRef.current;
        if (!canvas || !image.src) return;
        const ctx = canvas.getContext('2d');
        if (!ctx) return;

        ctx.clearRect(0, 0, canvas.width, canvas.height);
        ctx.drawImage(image, 0, 0, canvas.width, canvas.height);

        if (cropRect) {
            ctx.strokeStyle = 'rgba(236, 72, 153, 1)'; // pink-500
            ctx.lineWidth = 2;
            ctx.strokeRect(cropRect.x, cropRect.y, cropRect.width, cropRect.height);
            ctx.fillStyle = 'rgba(236, 72, 153, 0.2)';
            ctx.fillRect(cropRect.x, cropRect.y, cropRect.width, cropRect.height);
        }
    }, [cropRect]);

    useEffect(() => {
        const image = imageRef.current;
        const canvas = canvasRef.current;

        const handleImageLoad = () => {
            if (canvas) {
                const container = canvas.parentElement;
                if(container){
                    const maxWidth = container.clientWidth * 0.9;
                    const maxHeight = window.innerHeight * 0.7;
                    const aspectRatio = image.naturalWidth / image.naturalHeight;
                    
                    let newWidth = maxWidth;
                    let newHeight = newWidth / aspectRatio;

                    if (newHeight > maxHeight) {
                        newHeight = maxHeight;
                        newWidth = newHeight * aspectRatio;
                    }

                    canvas.width = newWidth;
                    canvas.height = newHeight;
                    draw();
                }
            }
        };

        image.crossOrigin = "anonymous";
        image.src = imageUrl;
        image.addEventListener('load', handleImageLoad);

        return () => {
            image.removeEventListener('load', handleImageLoad);
        };
    }, [imageUrl, draw]);

    useEffect(() => {
        draw();
    }, [draw]);

    const getCanvasPoint = (e: React.MouseEvent<HTMLCanvasElement>): { x: number, y: number } => {
        const canvas = canvasRef.current;
        if (!canvas) return { x: 0, y: 0 };
        const rect = canvas.getBoundingClientRect();
        return {
            x: e.clientX - rect.left,
            y: e.clientY - rect.top,
        };
    };

    const handleMouseDown = (e: React.MouseEvent<HTMLCanvasElement>) => {
        setIsDrawing(true);
        const point = getCanvasPoint(e);
        setStartPoint(point);
        setCropRect({ ...point, width: 0, height: 0 });
    };

    const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
        if (!isDrawing || !startPoint) return;
        const currentPoint = getCanvasPoint(e);
        const width = currentPoint.x - startPoint.x;
        const height = currentPoint.y - startPoint.y;
        setCropRect({
            x: width > 0 ? startPoint.x : currentPoint.x,
            y: height > 0 ? startPoint.y : currentPoint.y,
            width: Math.abs(width),
            height: Math.abs(height)
        });
    };

    const handleMouseUp = () => {
        setIsDrawing(false);
    };

    const handleSaveCrop = () => {
        const canvas = canvasRef.current;
        const image = imageRef.current;
        if (!canvas || !cropRect || cropRect.width === 0 || cropRect.height === 0) {
            alert("Please select an area to crop.");
            return;
        }

        const scaleX = image.naturalWidth / canvas.width;
        const scaleY = image.naturalHeight / canvas.height;

        const finalCrop = {
            x: cropRect.x * scaleX,
            y: cropRect.y * scaleY,
            width: cropRect.width * scaleX,
            height: cropRect.height * scaleY
        };

        const cropCanvas = document.createElement('canvas');
        cropCanvas.width = finalCrop.width;
        cropCanvas.height = finalCrop.height;
        const ctx = cropCanvas.getContext('2d');
        if (!ctx) return;

        ctx.drawImage(
            image,
            finalCrop.x, finalCrop.y, finalCrop.width, finalCrop.height,
            0, 0, finalCrop.width, finalCrop.height
        );
        onCrop(cropCanvas.toDataURL('image/jpeg', 0.95));
    };

    return (
        <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50 p-4 animate-fade-in" role="dialog" aria-modal="true" aria-labelledby="crop-modal-title">
            <div className="bg-gradient-to-br from-indigo-700 to-purple-800 rounded-2xl shadow-2xl p-6 w-full max-w-4xl text-white">
                <h2 id="crop-modal-title" className="text-2xl font-bold mb-4 capitalize text-center">
                    Cropping {itemToCrop.type.toLowerCase()} {itemToCrop.id}
                </h2>
                <div className="flex justify-center bg-black/30 rounded-lg p-2">
                    <canvas
                        ref={canvasRef}
                        onMouseDown={handleMouseDown}
                        onMouseMove={handleMouseMove}
                        onMouseUp={handleMouseUp}
                        onMouseLeave={handleMouseUp} // Stop drawing if mouse leaves canvas
                        className="cursor-crosshair rounded"
                    />
                </div>
                <p className="text-center text-indigo-300 mt-2">Click and drag on the image to select an area.</p>
                <div className="flex justify-center gap-4 mt-6">
                    <button onClick={onClose} className="bg-gray-500 font-bold py-2 px-6 rounded-full hover:bg-gray-600 transition-colors">
                        Cancel
                    </button>
                    <button onClick={handleSaveCrop} className="bg-green-500 font-bold py-2 px-6 rounded-full hover:bg-green-600 transition-colors disabled:bg-gray-400" disabled={!cropRect || cropRect.width === 0}>
                        Save Crop
                    </button>
                </div>
            </div>
        </div>
    );
};
