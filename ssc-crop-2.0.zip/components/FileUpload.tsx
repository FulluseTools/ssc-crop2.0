
import React, { useCallback, useState } from 'react';

interface FileUploadProps {
    onFileSelect: (file: File) => void;
}

export const FileUpload: React.FC<FileUploadProps> = ({ onFileSelect }) => {
    const [isDragging, setIsDragging] = useState(false);

    const handleDrag = useCallback((e: React.DragEvent<HTMLDivElement>) => {
        e.preventDefault();
        e.stopPropagation();
        if (e.type === 'dragenter' || e.type === 'dragover') {
            setIsDragging(true);
        } else if (e.type === 'dragleave') {
            setIsDragging(false);
        }
    }, []);

    const handleDrop = useCallback((e: React.DragEvent<HTMLDivElement>) => {
        e.preventDefault();
        e.stopPropagation();
        setIsDragging(false);
        if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
            onFileSelect(e.dataTransfer.files[0]);
            e.dataTransfer.clearData();
        }
    }, [onFileSelect]);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files.length > 0) {
            onFileSelect(e.target.files[0]);
        }
    };

    return (
        <div 
            onDragEnter={handleDrag}
            onDragLeave={handleDrag}
            onDragOver={handleDrag}
            onDrop={handleDrop}
            className={`text-center p-8 border-4 border-dashed rounded-xl transition-colors duration-300 ${isDragging ? 'border-pink-400 bg-white/20' : 'border-indigo-300 hover:border-pink-400'}`}
        >
            <input
                type="file"
                id="file-upload"
                className="hidden"
                accept="image/png, image/jpeg, image/webp"
                onChange={handleChange}
            />
            <label htmlFor="file-upload" className="cursor-pointer">
                <div className="flex flex-col items-center">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 mb-4 text-indigo-200" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12" />
                    </svg>
                    <p className="text-xl font-semibold text-white">Drag & drop your A4/A5 sheet here</p>
                    <p className="text-indigo-200 mt-1">or</p>
                    <span className="mt-2 bg-pink-500 text-white font-bold py-2 px-6 rounded-full hover:bg-pink-600 transition-transform hover:scale-105">
                        Click to Upload
                    </span>
                </div>
            </label>
        </div>
    );
};
